// Serveur de partage de position. Les positions restent en mémoire uniquement :
// rien n'est écrit sur disque, tout disparaît quand la personne arrête ou se déconnecte.
const express = require("express");
const http = require("http");
const { WebSocketServer } = require("ws");
const crypto = require("crypto");

const app = express();
app.use(express.static("public"));
const server = http.createServer(app);
const wss = new WebSocketServer({ server, maxPayload: 2048 });

const rooms = new Map(); // code -> Map(id -> { name, lat, lng, acc, t })

function broadcast(code) {
  const people = rooms.get(code);
  if (!people) return;
  const payload = JSON.stringify({
    type: "state",
    people: [...people].map(([id, p]) => ({ id, ...p })),
  });
  for (const c of wss.clients) {
    if (c.room === code && c.readyState === 1) c.send(payload);
  }
}

function leave(ws) {
  const people = rooms.get(ws.room);
  if (!people) return;
  people.delete(ws.id);
  if (people.size === 0) rooms.delete(ws.room);
  broadcast(ws.room);
}

wss.on("connection", (ws) => {
  ws.id = crypto.randomUUID();
  ws.room = null;
  ws.isAlive = true;
  ws.on("pong", () => (ws.isAlive = true));

  ws.on("message", (raw) => {
    let m;
    try { m = JSON.parse(raw); } catch { return; }

    if (m.type === "join") {
      const code = String(m.room || "").trim().toLowerCase();
      if (code.length < 6 || code.length > 40) {
        return ws.send(JSON.stringify({ type: "error", message: "Le code famille doit contenir au moins 6 caractères." }));
      }
      ws.room = code;
      ws.name = String(m.name || "Anonyme").slice(0, 30);
      if (!rooms.has(code)) rooms.set(code, new Map());
      ws.send(JSON.stringify({ type: "joined", id: ws.id }));
      broadcast(code);
    }

    if (m.type === "pos" && ws.room) {
      const { lat, lng, acc } = m;
      if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return;
      rooms.get(ws.room).set(ws.id, { name: ws.name, lat, lng, acc: Number(acc) || null, t: Date.now() });
      broadcast(ws.room);
    }

    if (m.type === "stop" && ws.room) {
      rooms.get(ws.room)?.delete(ws.id);
      broadcast(ws.room);
    }
  });

  ws.on("close", () => ws.room && leave(ws));
});

// Coupe les connexions mortes
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false;
    ws.ping();
  }
}, 30000);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Serveur sur http://localhost:${PORT}`));
