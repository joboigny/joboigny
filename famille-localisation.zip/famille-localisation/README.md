# Où sont-ils — partage de position en famille

Application web de partage de position en temps réel, **avec consentement**.

- Chaque personne ouvre la page, rejoint le groupe avec un code famille, puis coche son accord et appuie sur « Partager ma position ».
- Un bandeau jaune reste visible tant que le partage est actif. « Arrêter le partage » le coupe immédiatement.
- Les positions ne sont jamais enregistrées : elles restent en mémoire sur le serveur et disparaissent à l'arrêt ou à la déconnexion.

## Lancer en local

```bash
npm install
npm start
```
Ouvrez http://localhost:3000. Le GPS fonctionne sur `localhost`, mais sur un autre appareil il faut **HTTPS**.

## Mettre en ligne (HTTPS requis)

GitHub Pages ne convient pas (pas de serveur). Poussez ce dépôt sur GitHub, puis déployez-le sur un hébergeur Node gratuit ou peu cher
(Render, Railway, Fly.io) : commande de démarrage `npm start`. L'hébergeur fournit le HTTPS.

## Bon usage

Choisissez un code famille long et secret. Chaque membre doit installer/ouvrir la page lui-même et accepter le partage sur son propre téléphone.
